export const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: "ghostbridge-real.firebaseapp.com",
  projectId: "ghostbridge-real",
  storageBucket: "ghostbridge-real.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456",
  measurementId: "G-ABCDEFG123"
};